<div class="p-6 border-t border-gray-200 flex justify-between items-center text-sm text-gray-500 mt-auto">
  <div>© 2025 Land Admin System. All rights reserved.</div>
  <div class="flex items-center">
    <img src="{{ asset('storage/uploads/logo.jpeg') }}" alt="Logo"  style="width: 150px; height: auto;">
  </div>
</div>