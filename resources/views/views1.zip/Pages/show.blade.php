<div class="card">
    <div class="card-body">
        {!!  $page->content !!}
    </div>
</div>

